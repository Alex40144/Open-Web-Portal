# OpenWebPortal

# How to use:
* import OpenWebPortal as OWP or import folder.OpenWebPortal as OWP if in subfolder
* OWP.start() to start the web server
* define a variable:
    * x=OWP.OWP("string", True)
    * x is the reference to the variable
    * "string" is the name of the setting
    * True is the default(first) value of the variable
* to access the value of the variable:
    * x.value
